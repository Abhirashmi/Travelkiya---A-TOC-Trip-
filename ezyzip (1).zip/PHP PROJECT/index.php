<?php

$insert = false;
if(isset($_POST['name'])){

    // Set connection variables

$server = "localhost";
$username = "root";
$password = "";

// Create a database connection
$con = mysqli_connect($server, $username, $password);
// Check for connection success
if(!$con){
    die("connection to this database failed due to" . mysqli_connect_error());
}
    // echo "Success connecting to the db";

$name = $_POST['name'];
$age = $_POST['age'];
$branch_name =$_POST['branch_name'];
$year =$_POST['year'];
$gender = $_POST['gender'];
$email_id = $_POST['email_id'];
$phone_no = $_POST['phone_no'];
$other_info = $_POST['other_info'];

$sql = "INSERT INTO`trip`.`trip`(`name`, `age`, `branch_name`, `year`, `gender`, `email_id`, `phone_no`, `other_info`, `dd`) VALUES ('$name', '$age','$branch_name','$year', '$gender', '$email_id', '$phone_no', '$other_info', current_timestamp());";
    // echo $sql;

// Execute the query
if($con->query($sql) == true){
    // echo "Successfully inserted";

    // Flag for successful insertion
    $insert = true;
}
else{
    echo "ERROR: $sql <br> $con->error";
}

// Close the database connection
$con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travelkiya@kiit.ac.in</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <img class="logo" src="logo1.png" alt="Kiit logo">
    <img class="bg" src="bg.jpg" alt="background">
    
    <div class="container">
        <h1>Welcome to KiiT University TOC (Toronto, Ontario, Canada ) Trip form.</h3>
        <p>Enter your details and submit this form to confirm your participation in the trip. </p>
        <?php
        if($insert == true){
        echo "<p class='submitMsg'>Thanks for submitting your form!!!. We are happy to see you joining us for the TOC trip</p>";
        }
        ?>
        <form action="index.php" method="post">
            <input type="text" name="name" id="name" placeholder="Enter your name">
            <input type="text" name="age" id="age" placeholder="Enter your Age">
            <input type="text" name="branch_name" id="branch_name" placeholder="Enter your branch name">
            <input type="text" name="year" id="year" placeholder="Enter your College year">
            <input type="text" name="gender" id="gender" placeholder="Enter your gender">
            <input type="email" name="email_id" id="email" placeholder="Enter your email address">
            <input type="phone" name="phone_no" id="phone" placeholder="Enter your phone number">
            <textarea name="other_info" id="other_info" cols="30" rows="10" placeholder="Enter any other information you want to share with us !"></textarea>
            <button class="btn">Submit</button> 
        </form>
    </div>
    <script src="index.js"></script>
    
</body>
</html>


